package dataAccess;

public enum StorageType {
	MEMBERS, BOOK, PERIODICAL,CHECKOUT,COPY
}
